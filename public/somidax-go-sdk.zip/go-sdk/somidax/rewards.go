package somidax

import (
	"context"
	"fmt"
	"time"
)

type RewardsService struct{ c *Client }

type StakingTier string

const (
	TierSpark StakingTier = "spark"
	TierCore  StakingTier = "core"
	TierSurge StakingTier = "surge"
	TierApex  StakingTier = "apex"
)

type RewardAccount struct {
	CustomerID  string      `json:"customer_id"`
	Balance     float64     `json:"balance"`
	Staked      float64     `json:"staked"`
	Tier        StakingTier `json:"tier"`
	TotalEarned float64     `json:"total_earned"`
	TotalSpent  float64     `json:"total_spent"`
	UpdatedAt   time.Time   `json:"updated_at"`
}

type RewardTransaction struct {
	ID          string    `json:"id"`
	CustomerID  string    `json:"customer_id"`
	Type        string    `json:"type"`
	Amount      float64   `json:"amount"`
	OrderID     string    `json:"order_id,omitempty"`
	Description string    `json:"description,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
}

type EarnRequest struct {
	CustomerID string  `json:"customer_id"`
	OrderID    string  `json:"order_id"`
	Amount     float64 `json:"amount"`
}

type RedeemRequest struct {
	CustomerID string  `json:"customer_id"`
	OrderID    string  `json:"order_id,omitempty"`
	Amount     float64 `json:"amount"`
}

func (s *RewardsService) GetAccount(ctx context.Context, customerID string) (*RewardAccount, error) {
	var out RewardAccount
	return &out, s.c.do(ctx, "GET", fmt.Sprintf("/rewards/accounts/%s", customerID), nil, &out)
}

func (s *RewardsService) Earn(ctx context.Context, req EarnRequest) (*RewardTransaction, error) {
	var out RewardTransaction
	return &out, s.c.do(ctx, "POST", "/rewards/earn", req, &out)
}

func (s *RewardsService) Redeem(ctx context.Context, req RedeemRequest) (*RewardTransaction, error) {
	var out RewardTransaction
	return &out, s.c.do(ctx, "POST", "/rewards/redeem", req, &out)
}

func (s *RewardsService) ListTransactions(ctx context.Context, customerID string, params ListParams) (*ListResponse[RewardTransaction], error) {
	var out ListResponse[RewardTransaction]
	return &out, s.c.do(ctx, "GET", fmt.Sprintf("/rewards/accounts/%s/transactions", customerID), params, &out)
}
