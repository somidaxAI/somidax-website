package somidax

import (
	"context"
	"time"
)

type AnalyticsService struct{ c *Client }

type Period string

const (
	PeriodDay   Period = "day"
	PeriodWeek  Period = "week"
	PeriodMonth Period = "month"
	PeriodYear  Period = "year"
)

type OverviewMetrics struct {
	Period          Period    `json:"period"`
	From            time.Time `json:"from"`
	To              time.Time `json:"to"`
	TotalRevenue    Money     `json:"total_revenue"`
	TotalOrders     int       `json:"total_orders"`
	AOV             Money     `json:"aov"`
	UniqueCustomers int       `json:"unique_customers"`
	NewCustomers    int       `json:"new_customers"`
	RepeatRate      float64   `json:"repeat_rate"`
	SMDXDistributed float64   `json:"smdx_distributed"`
	SMDXRedeemed    float64   `json:"smdx_redeemed"`
}

type TopProduct struct {
	ProductID  string  `json:"product_id"`
	Name       string  `json:"name"`
	Units      int     `json:"units"`
	Revenue    Money   `json:"revenue"`
	ReturnRate float64 `json:"return_rate"`
}

type AnalyticsParams struct {
	Period Period    `json:"period,omitempty"`
	From   time.Time `json:"from,omitempty"`
	To     time.Time `json:"to,omitempty"`
}

func (s *AnalyticsService) Overview(ctx context.Context, params AnalyticsParams) (*OverviewMetrics, error) {
	var out OverviewMetrics
	return &out, s.c.do(ctx, "GET", "/analytics/overview", params, &out)
}

func (s *AnalyticsService) TopProducts(ctx context.Context, params AnalyticsParams) ([]TopProduct, error) {
	var out []TopProduct
	return out, s.c.do(ctx, "GET", "/analytics/top-products", params, &out)
}
