package somidax

import (
	"context"
	"fmt"
	"time"
)

type CatalogService struct{ c *Client }

type Product struct {
	ID          string            `json:"id"`
	MerchantID  string            `json:"merchant_id"`
	Name        string            `json:"name"`
	Description string            `json:"description"`
	Status      string            `json:"status"`
	Images      []string          `json:"images"`
	Tags        []string          `json:"tags,omitempty"`
	Variants    []Variant         `json:"variants"`
	Metadata    map[string]string `json:"metadata,omitempty"`
	CreatedAt   time.Time         `json:"created_at"`
	UpdatedAt   time.Time         `json:"updated_at"`
}

type Variant struct {
	ID         string            `json:"id"`
	ProductID  string            `json:"product_id"`
	SKU        string            `json:"sku"`
	Name       string            `json:"name"`
	Price      Money             `json:"price"`
	CompareAt  *Money            `json:"compare_at,omitempty"`
	Stock      int               `json:"stock"`
	Attributes map[string]string `json:"attributes,omitempty"`
}

type CreateProductRequest struct {
	Name        string            `json:"name"`
	Description string            `json:"description,omitempty"`
	Status      string            `json:"status,omitempty"`
	Images      []string          `json:"images,omitempty"`
	Tags        []string          `json:"tags,omitempty"`
	Variants    []CreateVariant   `json:"variants"`
	Metadata    map[string]string `json:"metadata,omitempty"`
}

type CreateVariant struct {
	SKU        string            `json:"sku"`
	Name       string            `json:"name"`
	Price      int64             `json:"price"`
	Currency   string            `json:"currency"`
	Stock      int               `json:"stock"`
	Attributes map[string]string `json:"attributes,omitempty"`
}

type UpdateProductRequest struct {
	Name        *string           `json:"name,omitempty"`
	Description *string           `json:"description,omitempty"`
	Status      *string           `json:"status,omitempty"`
	Images      []string          `json:"images,omitempty"`
	Tags        []string          `json:"tags,omitempty"`
	Metadata    map[string]string `json:"metadata,omitempty"`
}

func (s *CatalogService) Create(ctx context.Context, req CreateProductRequest) (*Product, error) {
	var out Product
	return &out, s.c.do(ctx, "POST", "/catalog/products", req, &out)
}

func (s *CatalogService) Get(ctx context.Context, id string) (*Product, error) {
	var out Product
	return &out, s.c.do(ctx, "GET", fmt.Sprintf("/catalog/products/%s", id), nil, &out)
}

func (s *CatalogService) List(ctx context.Context, params ListParams) (*ListResponse[Product], error) {
	var out ListResponse[Product]
	return &out, s.c.do(ctx, "GET", "/catalog/products", params, &out)
}

func (s *CatalogService) Update(ctx context.Context, id string, req UpdateProductRequest) (*Product, error) {
	var out Product
	return &out, s.c.do(ctx, "PATCH", fmt.Sprintf("/catalog/products/%s", id), req, &out)
}

func (s *CatalogService) Delete(ctx context.Context, id string) error {
	archived := "archived"
	return s.c.do(ctx, "PATCH", fmt.Sprintf("/catalog/products/%s", id), UpdateProductRequest{Status: &archived}, nil)
}
