package somidax

import (
	"context"
	"fmt"
	"time"
)

type OrdersService struct{ c *Client }

type OrderStatus string

const (
	OrderStatusPending    OrderStatus = "pending"
	OrderStatusConfirmed  OrderStatus = "confirmed"
	OrderStatusProcessing OrderStatus = "processing"
	OrderStatusShipped    OrderStatus = "shipped"
	OrderStatusDelivered  OrderStatus = "delivered"
	OrderStatusCancelled  OrderStatus = "cancelled"
	OrderStatusRefunded   OrderStatus = "refunded"
)

type Order struct {
	ID           string            `json:"id"`
	MerchantID   string            `json:"merchant_id"`
	CustomerID   string            `json:"customer_id"`
	Status       OrderStatus       `json:"status"`
	Items        []OrderItem       `json:"items"`
	Subtotal     Money             `json:"subtotal"`
	Tax          Money             `json:"tax"`
	Shipping     Money             `json:"shipping"`
	Total        Money             `json:"total"`
	Currency     string            `json:"currency"`
	RewardEarned *RewardAmount     `json:"reward_earned,omitempty"`
	Metadata     map[string]string `json:"metadata,omitempty"`
	CreatedAt    time.Time         `json:"created_at"`
	UpdatedAt    time.Time         `json:"updated_at"`
}

type OrderItem struct {
	ProductID  string `json:"product_id"`
	VariantID  string `json:"variant_id,omitempty"`
	Name       string `json:"name"`
	SKU        string `json:"sku,omitempty"`
	Quantity   int    `json:"quantity"`
	UnitPrice  Money  `json:"unit_price"`
	TotalPrice Money  `json:"total_price"`
}

type Money struct {
	Amount   int64  `json:"amount"`
	Currency string `json:"currency"`
}

type RewardAmount struct {
	SMDX     float64 `json:"smdx"`
	USDValue float64 `json:"usd_value"`
}

type CreateOrderRequest struct {
	CustomerID string            `json:"customer_id"`
	Items      []CreateOrderItem `json:"items"`
	Currency   string            `json:"currency"`
	Metadata   map[string]string `json:"metadata,omitempty"`
}

type CreateOrderItem struct {
	ProductID string `json:"product_id"`
	VariantID string `json:"variant_id,omitempty"`
	Quantity  int    `json:"quantity"`
}

type UpdateOrderRequest struct {
	Status   *OrderStatus      `json:"status,omitempty"`
	Metadata map[string]string `json:"metadata,omitempty"`
}

type ListOrdersParams struct {
	ListParams
	Status     OrderStatus `json:"status,omitempty"`
	CustomerID string      `json:"customer_id,omitempty"`
}

func (s *OrdersService) Create(ctx context.Context, req CreateOrderRequest) (*Order, error) {
	var out Order
	return &out, s.c.do(ctx, "POST", "/orders", req, &out)
}

func (s *OrdersService) Get(ctx context.Context, id string) (*Order, error) {
	var out Order
	return &out, s.c.do(ctx, "GET", fmt.Sprintf("/orders/%s", id), nil, &out)
}

func (s *OrdersService) List(ctx context.Context, params ListOrdersParams) (*ListResponse[Order], error) {
	var out ListResponse[Order]
	return &out, s.c.do(ctx, "GET", "/orders", params, &out)
}

func (s *OrdersService) Update(ctx context.Context, id string, req UpdateOrderRequest) (*Order, error) {
	var out Order
	return &out, s.c.do(ctx, "PATCH", fmt.Sprintf("/orders/%s", id), req, &out)
}

func (s *OrdersService) Cancel(ctx context.Context, id string) (*Order, error) {
	status := OrderStatusCancelled
	return s.Update(ctx, id, UpdateOrderRequest{Status: &status})
}
