package somidax

import (
	"context"
	"fmt"
	"time"
)

type PaymentsService struct{ c *Client }

type PaymentStatus string

const (
	PaymentStatusPending  PaymentStatus = "pending"
	PaymentStatusSettled  PaymentStatus = "settled"
	PaymentStatusFailed   PaymentStatus = "failed"
	PaymentStatusRefunded PaymentStatus = "refunded"
)

type PaymentMethod string

const (
	PaymentMethodFiat   PaymentMethod = "fiat"
	PaymentMethodSMDX   PaymentMethod = "smdx"
	PaymentMethodCrypto PaymentMethod = "crypto"
)

type Payment struct {
	ID            string        `json:"id"`
	OrderID       string        `json:"order_id"`
	MerchantID    string        `json:"merchant_id"`
	Amount        Money         `json:"amount"`
	Fee           Money         `json:"fee"`
	NetAmount     Money         `json:"net_amount"`
	Method        PaymentMethod `json:"method"`
	Status        PaymentStatus `json:"status"`
	SettledAt     *time.Time    `json:"settled_at,omitempty"`
	TxHash        string        `json:"tx_hash,omitempty"`
	FailureReason string        `json:"failure_reason,omitempty"`
	CreatedAt     time.Time     `json:"created_at"`
}

type CreatePaymentRequest struct {
	OrderID   string        `json:"order_id"`
	Amount    int64         `json:"amount"`
	Currency  string        `json:"currency"`
	Method    PaymentMethod `json:"method"`
	ReturnURL string        `json:"return_url,omitempty"`
}

type RefundRequest struct {
	Amount int64  `json:"amount,omitempty"`
	Reason string `json:"reason,omitempty"`
}

type Refund struct {
	ID        string        `json:"id"`
	PaymentID string        `json:"payment_id"`
	Amount    Money         `json:"amount"`
	Reason    string        `json:"reason,omitempty"`
	Status    PaymentStatus `json:"status"`
	CreatedAt time.Time     `json:"created_at"`
}

func (s *PaymentsService) Create(ctx context.Context, req CreatePaymentRequest) (*Payment, error) {
	var out Payment
	return &out, s.c.do(ctx, "POST", "/payments", req, &out)
}

func (s *PaymentsService) Get(ctx context.Context, id string) (*Payment, error) {
	var out Payment
	return &out, s.c.do(ctx, "GET", fmt.Sprintf("/payments/%s", id), nil, &out)
}

func (s *PaymentsService) List(ctx context.Context, params ListParams) (*ListResponse[Payment], error) {
	var out ListResponse[Payment]
	return &out, s.c.do(ctx, "GET", "/payments", params, &out)
}

func (s *PaymentsService) Refund(ctx context.Context, paymentID string, req RefundRequest) (*Refund, error) {
	var out Refund
	return &out, s.c.do(ctx, "POST", fmt.Sprintf("/payments/%s/refund", paymentID), req, &out)
}
