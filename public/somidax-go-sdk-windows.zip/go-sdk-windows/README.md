# Somidax Windows CLI SDK

Command-line interface for the [Somidax](https://somidax.com) AI-native e-commerce platform.

## Installation

### Windows (PowerShell one-liner)

```powershell
iwr -useb https://raw.githubusercontent.com/somidaxAI/go-sdk-windows/main/scripts/install.ps1 | iex
```

### Manual download

Download the latest binary from [Releases](https://github.com/somidaxAI/go-sdk-windows/releases).

## Quick start

```cmd
somidax configure --api-key YOUR_API_KEY
somidax orders list
somidax analytics overview --period 30d
```

## Commands

| Command | Description |
|---|---|
| `somidax configure` | Save API key |
| `somidax orders list` | List recent orders |
| `somidax orders get <id>` | Get a single order |
| `somidax payments list` | List payments |
| `somidax analytics overview` | Store analytics |
| `somidax catalog list` | List products |
| `somidax version` | Print version |

## Build from source

```bash
git clone https://github.com/somidaxAI/go-sdk-windows
cd go-sdk-windows
go build -o somidax.exe ./cmd/somidax
```

## License

Apache 2.0 — see [LICENSE](LICENSE)
