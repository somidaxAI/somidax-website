# Somidax CLI Installer for Windows
# Run with: iwr -useb https://raw.githubusercontent.com/somidaxAI/go-sdk-windows/main/scripts/install.ps1 | iex

$ErrorActionPreference = "Stop"

$repo = "somidaxAI/go-sdk-windows"
$binary = "somidax-windows-amd64.exe"
$installDir = "$env:LOCALAPPDATA\Somidax"

Write-Host "Installing Somidax CLI..." -ForegroundColor Cyan

# Get latest release
$release = Invoke-RestMethod "https://api.github.com/repos/$repo/releases/latest"
$asset = $release.assets | Where-Object { $_.name -eq $binary } | Select-Object -First 1

if (-not $asset) {
    Write-Error "Could not find release asset: $binary"
    exit 1
}

# Create install directory
New-Item -ItemType Directory -Force -Path $installDir | Out-Null

# Download binary
$dest = Join-Path $installDir "somidax.exe"
Write-Host "Downloading $($asset.name)..."
Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $dest

# Add to PATH
$currentPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($currentPath -notlike "*$installDir*") {
    [Environment]::SetEnvironmentVariable("Path", "$currentPath;$installDir", "User")
    Write-Host "Added $installDir to PATH" -ForegroundColor Green
}

Write-Host ""
Write-Host "Somidax CLI installed successfully!" -ForegroundColor Green
Write-Host "Run: somidax configure --api-key YOUR_KEY"
Write-Host "Docs: https://docs.somidax.com/cli"
