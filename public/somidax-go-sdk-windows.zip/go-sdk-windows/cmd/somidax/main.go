package main

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/somidaxAI/go-sdk-windows/internal/api"
	"github.com/somidaxAI/go-sdk-windows/internal/config"
	"github.com/spf13/cobra"
)

var rootCmd = &cobra.Command{
	Use:   "somidax",
	Short: "Somidax CLI - manage your AI-native storefront from the command line",
	Long: `Somidax CLI for Windows
Manage orders, payments, catalog, and analytics from your terminal.

Documentation: https://docs.somidax.com/cli
GitHub:        https://github.com/somidaxAI/go-sdk-windows`,
}

var configureCmd = &cobra.Command{
	Use:   "configure",
	Short: "Set your Somidax API key",
	RunE: func(cmd *cobra.Command, args []string) error {
		apiKey, _ := cmd.Flags().GetString("api-key")
		baseURL, _ := cmd.Flags().GetString("base-url")
		if apiKey == "" {
			return fmt.Errorf("--api-key is required")
		}
		if err := config.Save(apiKey, baseURL); err != nil {
			return err
		}
		fmt.Println("Configuration saved.")
		return nil
	},
}

var ordersCmd = &cobra.Command{
	Use:   "orders",
	Short: "Manage orders",
}

var ordersListCmd = &cobra.Command{
	Use:   "list",
	Short: "List recent orders",
	RunE: func(cmd *cobra.Command, args []string) error {
		client, err := newClient()
		if err != nil {
			return err
		}
		limit, _ := cmd.Flags().GetInt("limit")
		var result interface{}
		if err := client.Get(fmt.Sprintf("/orders?limit=%d", limit), &result); err != nil {
			return err
		}
		return printJSON(result)
	},
}

var ordersGetCmd = &cobra.Command{
	Use:   "get <order-id>",
	Short: "Get a single order",
	Args:  cobra.ExactArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		client, err := newClient()
		if err != nil {
			return err
		}
		var result interface{}
		if err := client.Get("/orders/"+args[0], &result); err != nil {
			return err
		}
		return printJSON(result)
	},
}

var paymentsCmd = &cobra.Command{
	Use:   "payments",
	Short: "Manage payments",
}

var paymentsListCmd = &cobra.Command{
	Use:   "list",
	Short: "List recent payments",
	RunE: func(cmd *cobra.Command, args []string) error {
		client, err := newClient()
		if err != nil {
			return err
		}
		limit, _ := cmd.Flags().GetInt("limit")
		var result interface{}
		if err := client.Get(fmt.Sprintf("/payments?limit=%d", limit), &result); err != nil {
			return err
		}
		return printJSON(result)
	},
}

var analyticsCmd = &cobra.Command{
	Use:   "analytics",
	Short: "View store analytics",
}

var analyticsOverviewCmd = &cobra.Command{
	Use:   "overview",
	Short: "Show analytics overview",
	RunE: func(cmd *cobra.Command, args []string) error {
		client, err := newClient()
		if err != nil {
			return err
		}
		period, _ := cmd.Flags().GetString("period")
		var result interface{}
		if err := client.Get("/analytics/overview?period="+period, &result); err != nil {
			return err
		}
		return printJSON(result)
	},
}

var catalogCmd = &cobra.Command{
	Use:   "catalog",
	Short: "Manage product catalog",
}

var catalogListCmd = &cobra.Command{
	Use:   "list",
	Short: "List products",
	RunE: func(cmd *cobra.Command, args []string) error {
		client, err := newClient()
		if err != nil {
			return err
		}
		limit, _ := cmd.Flags().GetInt("limit")
		var result interface{}
		if err := client.Get(fmt.Sprintf("/catalog/products?limit=%d", limit), &result); err != nil {
			return err
		}
		return printJSON(result)
	},
}

var versionCmd = &cobra.Command{
	Use:   "version",
	Short: "Print version information",
	Run: func(cmd *cobra.Command, args []string) {
		fmt.Println("somidax version 1.0.0")
		fmt.Println("https://github.com/somidaxAI/go-sdk-windows")
	},
}

func newClient() (*api.Client, error) {
	cfg, err := config.Load()
	if err != nil {
		return nil, err
	}
	return api.New(cfg.BaseURL, cfg.APIKey), nil
}

func printJSON(v interface{}) error {
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	return enc.Encode(v)
}

func init() {
	configureCmd.Flags().String("api-key", "", "Your Somidax API key (required)")
	configureCmd.Flags().String("base-url", "", "API base URL (default: https://api.somidax.com/v1)")

	ordersListCmd.Flags().Int("limit", 20, "Number of orders to return")
	paymentsListCmd.Flags().Int("limit", 20, "Number of payments to return")
	catalogListCmd.Flags().Int("limit", 20, "Number of products to return")
	analyticsOverviewCmd.Flags().String("period", "30d", "Time period (7d, 30d, 90d)")

	ordersCmd.AddCommand(ordersListCmd, ordersGetCmd)
	paymentsCmd.AddCommand(paymentsListCmd)
	analyticsCmd.AddCommand(analyticsOverviewCmd)
	catalogCmd.AddCommand(catalogListCmd)

	rootCmd.AddCommand(configureCmd, ordersCmd, paymentsCmd, analyticsCmd, catalogCmd, versionCmd)
}

func main() {
	if err := rootCmd.Execute(); err != nil {
		os.Exit(1)
	}
}
